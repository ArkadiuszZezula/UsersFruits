var Object = {
    redirect: function (parameter) {
        if (parameter != 1 || (parameter == 1 && Number.isInteger(parameter) == true)) {
            window.location.replace("http://google.pl");
        }
    }
}

function testFunction() {
    element = document.getElementById("test").value
    document.getElementById("test").value = "random text";
    Object.redirect(element);
}
