<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Js</title>
</head>
<body>
<input id="test" type="text">
<button onclick="testFunction()">Try it</button>
</body>
<script src="js/app.js"></script>
</html>