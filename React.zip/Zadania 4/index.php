<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>React</title>
    <script src="https://unpkg.com/react/umd/react.development.js"></script>
    <script src="https://unpkg.com/react-dom/umd/react-dom.development.js"></script>
    <script src="https://unpkg.com/babel-standalone/babel.js"></script>
</head>
<body>
<div id="react_component"></div>
<div id="react_class"></div>
<script type="text/babel">

    class Counter extends React.Component {
        constructor() {
            super();
            this.state = {counter: 0};
        }

        render() {
            return (
                <div>
                    <button onClick={this.increment.bind(this)}>+</button>
                    <output>{this.state.counter}</output>
                </div>
            );
        }

        increment() {
            this.setState({
                counter: this.state.counter + 1
            })
        }
    }

    function Component({title, content}) {
        return (
            <div>
                <box>
                    <h1>{title}</h1>
                    <p>{content}</p>
                </box>
            </div>
        );
    }

    ReactDOM.render(<Counter/>, document.getElementById("react_class"));
    ReactDOM.render(<Component title="Licznik"
                               content="Kliknij aby zwiększyć licznik"/>, document.getElementById("react_component"));
</script>
</body>
</html>