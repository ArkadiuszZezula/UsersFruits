<?php

// Zagadnienia z SQL:
// Podstawowe komendy i ich zastosowanie:
//
// 1. Utworzenie tabeli create table -
//    CREATE TABLE users (
//    id INT(6) AUTO_INCREMENT PRIMARY KEY,
//    name VARCHAR(128) NOT NULL,
//    added DATE() NOT NULL
//    )
//    Utworzy tabelę `users` z trzema kolumnami, jedno pole liczbowe, którego numer rośnie z każdym wpisem oraz jedno tekstowe i jedno z datą.
//
// 2. Dodanie rekordu do tabeli insert -
//    INSERT INTO users (username, added)
//    VALUES ('Jan Kowalski', '2018-04-12')
//    Dodaje nowy wpis.
//
// 3. Zmiana danych w tabeli update -
//    UPDATE users
//    SET name='Marian Nowak'
//    WHERE id=1;
//    Uaktualnia rekord o wskazanych kryteriach (id=1) ustawiając mu nową wartość (name='Marian Nowak').
//
// 4. Pobranie danych konstrukcja select
//    SELECT * FROM users;
//    Pobiera wszystkie rekordy z tabeli `users`.
//
// 5. Łączenie tabel konstrukcja join, inner join, left join, right join
//    SELECT * FROM users_fruits INNER JOIN
//    users ON users_fruits.users_id = users.id;
//    Zwraca wyniki z połączonych tabel.
//
// 6. Zawężenie rekordów słowo kluczowe „where”
//    SELECT * FROM users
//    WHERE username = 'Marian Nowak';
//    WHERE username = LIKE "Mar%";
//    Zwraca tylko wyniki zawierające wskazane kryteria
//
// 7. wykorzystanie podzapytania konstrukcja „in” -
//    SELECT * FROM users
//    WHERE id IN ( 1,2,3);
//    Zwraca wszystkie rekordy które pasują do zbioru kryteriów.
//
// 8. Słowa kluczowe „order by” oraz „limit”
//    SELECT * FROM users ORDER BY username DESC limit 5;
//    Zwraca 5 rekordów posortowanych malejąco po wartości pola username.
//
// 9. Grupowanie i agregacja wyników słowa kluczowe „group by”
//    SELECT * FROM users GROUP BY username;
//    Zwraca rekordy zgrupowane po polu username.


//Pytania do zadania:
// 1. Jaka jest różnica między join, inner join, left join, right join
//    INNER JOIN - daje tylko wiersze które spełniają warunek.
//    LEFT JOIN - zwraca jako wynik wszystkie wiersze z lewej tabeli. Dane z prawej tabeli zostan dołączone tylko w rzędach spełniających warunek.
//    RIGHT JOIN - zwraca jako wynik wszystkie wiersze z prawej tabeli. Dane z lewej tabeli zostan dołączone tylko w rzędach spełniających warunek.
//
// 2. Jakie funkcje agregujące udało się sprawdzić.
//      Funkcje agregujące to:
//      AVG - średnia,
//      COUNT - liczba wystąpień,
//      MAX - maksimum,
//      MIN - minimum,
//      SUM - suma.


$servername = "localhost";
$username = "user";
$password = "password";
$baseName = "";

$conn = new mysqli($servername, $username, $password, $baseName);

if ($conn->connect_error) {
    die("Error: " .
        $conn->connect_error . PHP_EOL);
}

// Tworzenie bazy danych
$baseName = 'Users_fruits';
$sql = "CREATE DATABASE {$baseName}
        DEFAULT CHARACTER SET utf8
        DEFAULT COLLATE utf8_polish_ci;";
$result = $conn->query($sql);
if ($result != FALSE) {
    print('DB created.' . PHP_EOL);
} else {
    print('DB not created. Error: '
        . $conn->error . PHP_EOL);
}
$conn = new mysqli($servername, $username, $password, $baseName);
$conn->query('SET NAMES utf8');
$conn->query('SET CHARACTER_SET utf8_unicode_ci');

// Tworzy tabele users
$sql = 'CREATE TABLE users (
        id INT(6) AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(64) NOT NULL,
        added DATE NOT NULL
)';
$result = $conn->query($sql);
if ($result != FALSE) {
    print('Table users created.' . PHP_EOL);
} else {
    print('Table users not created. Error: '
        . $conn->error . PHP_EOL);
}

// Tworzy tabele fruits
$sql = 'CREATE TABLE fruits (
        id INT(6) AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(64) NOT NULL
)';
$result = $conn->query($sql);
if ($result != FALSE) {
    print('Table fruits created.' . PHP_EOL);
} else {
    print('Table fruits not created. Error: '
        . $conn->error . PHP_EOL);
}


$users = array('Jan Kowalski', 'Stanisław Nowak', 'Kazimierz Iksiński', 'Karol Nowacki', 'Marcin Nowostocki');
$fruits = ['Apple', 'Orange', 'Lemon', 'Banana', 'Mango'];
$date_now = date('Y-m-d');

// Dodaje wpisy do tabeli users
$number_of_users = count($users);
$counter_users = 0;
foreach ($users as $user) {
    $sql = "INSERT INTO users (name, added) VALUES ('{$user}', '{$date_now}')";
    $result = $conn->query($sql);
    if ($result != FALSE) {
        $counter_users++;
    } else {
        print("$user not created. Error: "
            . $conn->error . PHP_EOL);
    }
}
if ($number_of_users == $counter_users) {
    print('All users have been added.' . PHP_EOL);
} else {
    print('Unable to add all users.' . PHP_EOL);
    die();
}

// Dodaje wpisy do tabeli fruits
$number_of_fruits = count($fruits);
$counter_fruits = 0;
foreach ($fruits as $fruit) {
    $sql = "INSERT INTO fruits (name) VALUES ('{$fruit}')";
    $result = $conn->query($sql);
    if ($result != FALSE) {
        $counter_fruits++;
    } else {
        print("$fruit not created. Error: "
            . $conn->error . PHP_EOL);
    }
}
if ($number_of_fruits == $counter_fruits) {
    print('All fruits have been added.' . PHP_EOL);
} else {
    print('Unable to add all fruits.' . PHP_EOL);
    die();
}

// Tworzy tabele users_fruits
$sql = "CREATE TABLE Users_fruits.users_fruits (
        id INT(6) UNSIGNED AUTO_INCREMENT,
        users_id INT(6) NOT NULL,
        fruits_id INT(6) NOT NULL,
        PRIMARY KEY(id),
        FOREIGN KEY(users_id) REFERENCES users(id),
        FOREIGN KEY(fruits_id) REFERENCES fruits(id)
)";
$result = $conn->query($sql);
if ($result != FALSE) {
    print('Table users_fruits created.' . PHP_EOL);
} else {
    print('Table users_fruits not created. Error: '
        . $conn->error . PHP_EOL);
}

// Dodaje wpisy do tabeli users_fruits
$counter_users_fruits = 0;
for ($i = 0; $i < 10; $i++) {
    $user_id = rand(1, 5);
    $fruit_id = rand(1, 5);
    $sql_exist = "SELECT * from users_fruits where `users_id` = '{$user_id}' AND `fruits_id` = '{$fruit_id}'";
    $exist_record = $conn->query($sql_exist);
    if ($exist_record->num_rows == 0) {
        $sql = "INSERT INTO users_fruits (users_id, fruits_id) VALUES ('{$user_id}', '{$fruit_id}')";
        $result = $conn->query($sql);
        if ($result == FALSE) {
            print("Error: " . $conn->error . PHP_EOL);
        }
        $counter_users_fruits++;
    }
}
if ($counter_users_fruits > 0) {
    print('Added ' . $counter_users_fruits . 'new realtions(user - fruit)' . PHP_EOL);
} else {
    print('No relations(user - fruits) have been added.' . PHP_EOL);
    die();
}

//Zmiana danych w tabeli - update i where
$sql = "UPDATE users SET name='Marian Nowak' WHERE id=1";
$result = $conn->query($sql);
if ($result != FALSE) {
    print("The users table has been updated.");
} else {
    print("The users table has not been updated. Error: "
        . $conn->error . PHP_EOL);
}

// Konstrukcje z listy niewykorzystane wcześniej w zapytaniach

//Pobranie danych konstrukcja select i łączenie tabel konstrukcja join
$sql = "SELECT users.name as `username`, users.added, fruits.name as fruit_name FROM users_fruits INNER JOIN users ON users_fruits.users_id = users.id INNER JOIN fruits ON users_fruits.fruits_id = fruits.id";
$result = $conn->query($sql);
if ($result != FALSE) {
    $join_result = $result;
} else {
    print("Error: "
        . $conn->error . PHP_EOL);
}

//Wykorzystanie podzapytania konstrukcja IN, order by, limit
$sql = "SELECT * FROM users WHERE id IN (1,2,3,4) ORDER BY name DESC LIMIT 3";
$result = $conn->query($sql);
if ($result != FALSE) {
    $in = $result;
} else {
    print("Error: "
        . $conn->error . PHP_EOL);
}

$conn->close();
$conn = null;
