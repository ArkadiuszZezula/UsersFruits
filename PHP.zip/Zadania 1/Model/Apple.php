<?php

include_once "Fruit.php";

class Apple extends Fruit
{
    public function __construct()
    {
        $this->setType('Apple');
    }

    private function setType($type){
        $this->type = $type;
    }

}