<?php

Interface PlantInterface
{

    public function getType();

}
