<?php

include_once "Plant.php";

class Fruit extends Plant
{

}