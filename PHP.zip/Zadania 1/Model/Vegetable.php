<?php

include_once "Plant.php";

class Vegetable extends Plant
{

}