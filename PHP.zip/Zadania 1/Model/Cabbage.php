<?php

include_once "Vegetable.php";

class Cabbage extends Vegetable
{
    protected $type = 'Cabbage';
}