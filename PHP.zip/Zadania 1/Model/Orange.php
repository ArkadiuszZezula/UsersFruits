<?php

include_once "Fruit.php";

class Orange extends Fruit
{
    public function __construct()
    {
        $this->type = 'Orange';
    }

    public static function make()
    {
        return 'orange juice';
    }

}