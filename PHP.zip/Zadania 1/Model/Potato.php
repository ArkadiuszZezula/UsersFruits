<?php

include_once "Vegetable.php";

class Potato extends Vegetable
{
    public $type = 'Potato';
}