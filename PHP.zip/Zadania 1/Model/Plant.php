<?php

include_once "PlantInterface.php";

abstract class Plant implements PlantInterface
{

    protected $type = 'Other';

}