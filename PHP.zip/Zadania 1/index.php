<?php

spl_autoload_register(function ($class_name) {
    include 'Model/' . $class_name . '.php';
});

function checkObject (Fruit $obj){
    return $obj->getType();
}

$Orange = new Orange();
$Apple = new Apple();
$Cabbage = new Cabbage();
$Potato = new Potato();

$Apple->getType();
$Cabbage->getType();
$Potato->getType();
checkObject($Apple);
checkObject($Cabbage);
checkObject($Potato);
$Orange::make();

//Odpowiedzi na pytania z klas i obiektów:
//
//1. Różnica między public, protected, private
//    - public - atrybut lub metoda jest widoczna zarówno ze środka klasy, klas dziedziczonych jak i z zewnątrz klasy;
//    - protected - atrybut lub metoda jest widoczna tylko z wnętrza danej klasy i klas dziedziczących;
//    - private - atrybut lub metoda nie jest widoczna na zewnątrz klasy i nie może być dziedziczona;
//2. Dlaczego brak metody getType w klasie Fruit powoduje błąd - Z powodu nie implementowania metody wymaganej przez interface.
//3. Czym jest klasa abstrakcyjna - Klasa abstrakcyjna jest to klasa której obiekty nie mogą być tworzone,może być natomiast dziedziczona. Metody abstrakcyjne zawierają jedynie definicję samej metody (widoczność, liczbę i rodzaj argumentów) bez jej kodu. Dziedzicząc po klasie abstrakcyjnej, musimy zachować nie tylko zgodność dostępu, lecz także typów i liczby argumentów.
//4. Co trzeba zmienić w funkcji checkObject by działała poprawnie i dlaczego - nie definiować lub zmienić obiekt typu Fruit na Plant, gdyż nie wszystkie Obiekty wywołujące tą funkcje dziedziczyły po klasie Fruit.
//5. Jak można zastosować wyjątki (konstrukcja try cache) by zapobiec błędne wywołania funkcji checkObject (PHP 7 TypeError) - np wywołując funkcję:
//function checkObjectAndType ($obj){
//    try {
//        checkObject($obj);
//    } catch (Throwable $t) {
//        echo $t->getMessage(), "\n";
//    }
//}



//Operacje na tablicach danych / tablicach obiektów

$names = array('Jan Kowalski', 'Stanisław Nowak', 'Kazimierz Iksiński', 'Karol Nowacki', 'Marcin Nowostocki');
$plants = ['Apple', 'Orange', 'Cabbage', 'Potato', 'Other'];

foreach ($names as $key => $row){
    $names[$row] = $plants[array_rand($plants)];
    unset($names[$key]);
}
ksort($names);
foreach ($names as $key => $row){
    if($row == "Apple"){
        unset($names[$key]);
    }
}
print_r($names);
